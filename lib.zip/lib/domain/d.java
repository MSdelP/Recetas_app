package domain;

public class d {
}
